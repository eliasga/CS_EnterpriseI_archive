<portlist>
<inport> Id = "1"  Name = "Switch_subsystem/Triangle" Width = "1" DataType = "real_T" </inport>
<inport> Id = "2"  Name = "Switch_subsystem/Circle" Width = "1" DataType = "real_T" </inport>
<inport> Id = "3"  Name = "Switch_subsystem/Cross" Width = "1" DataType = "real_T" </inport>
<inport> Id = "4"  Name = "Switch_subsystem/Square" Width = "1" DataType = "real_T" </inport>
<inport> Id = "5"  Name = "ctrl_custom/u_BT" Width = "1" DataType = "real_T" </inport>
<inport> Id = "6"  Name = "ctrl_custom/u_VSP2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "7"  Name = "ctrl_custom/omega_VSP1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "8"  Name = "ctrl_custom/omega_VSP2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "9"  Name = "ctrl_custom/u_VSP1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "10"  Name = "ctrl_custom/alpha_VSP1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "11"  Name = "ctrl_custom/alpha_VSP2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "12"  Name = "ctrl_DP/u_BT" Width = "1" DataType = "real_T" </inport>
<inport> Id = "13"  Name = "ctrl_DP/u_VSP2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "14"  Name = "ctrl_DP/omega_VSP1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "15"  Name = "ctrl_DP/omega_VSP2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "16"  Name = "ctrl_DP/u_VSP1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "17"  Name = "ctrl_DP/alpha_VSP1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "18"  Name = "ctrl_DP/alpha_VSP2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "19"  Name = "ctrl_sixaxis2thruster/u_BT" Width = "1" DataType = "real_T" </inport>
<inport> Id = "20"  Name = "ctrl_sixaxis2thruster/u_VSP2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "21"  Name = "ctrl_sixaxis2thruster/omega_VSP1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "22"  Name = "ctrl_sixaxis2thruster/omega_VSP2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "23"  Name = "ctrl_sixaxis2thruster/u_VSP1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "24"  Name = "ctrl_sixaxis2thruster/alpha_VSP1" Width = "1" DataType = "real_T" </inport>
<inport> Id = "25"  Name = "ctrl_sixaxis2thruster/alpha_VSP2" Width = "1" DataType = "real_T" </inport>
<inport> Id = "26"  Name = "enable_mech_el" Width = "1" DataType = "real_T" </inport>
<outport> Id = "1"  Name = "control input u exceeds bounds" Width = "1" DataType = "boolean_T" </outport>
<outport> Id = "2"  Name = "indicator/ctrl_custom" Width = "1" DataType = "boolean_T" </outport>
<outport> Id = "3"  Name = "indicator/ctrl_DP" Width = "1" DataType = "boolean_T" </outport>
<outport> Id = "4"  Name = "indicator/STOP" Width = "1" DataType = "boolean_T" </outport>
<outport> Id = "5"  Name = "indicator/ctrl_sixaxis2thruster" Width = "1" DataType = "boolean_T" </outport>
<outport> Id = "6"  Name = "pwm/pwm_VSP1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "7"  Name = "pwm/pwm_VSP2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "8"  Name = "pwm/pwm_BT" Width = "1" DataType = "real_T" </outport>
<outport> Id = "9"  Name = "pwm/pwm_servo4" Width = "1" DataType = "real_T" </outport>
<outport> Id = "10"  Name = "pwm/pwm_servo3" Width = "1" DataType = "real_T" </outport>
<outport> Id = "11"  Name = "pwm/pwm_servo1" Width = "1" DataType = "real_T" </outport>
<outport> Id = "12"  Name = "pwm/pwm_servo2" Width = "1" DataType = "real_T" </outport>
<outport> Id = "13"  Name = "to HIL subsystem/u_BT_HIL" Width = "1" DataType = "real_T" </outport>
<outport> Id = "14"  Name = "to HIL subsystem/u_VSP1_HIL" Width = "1" DataType = "real_T" </outport>
<outport> Id = "15"  Name = "to HIL subsystem/u_VSP2_HIL" Width = "1" DataType = "real_T" </outport>
<outport> Id = "16"  Name = "to HIL subsystem/alpha_VSP1_HIL" Width = "1" DataType = "real_T" </outport>
<outport> Id = "17"  Name = "to HIL subsystem/alpha_VSP2_HIL" Width = "1" DataType = "real_T" </outport>
<outport> Id = "18"  Name = "to HIL subsystem/omega_VSP1_HIL" Width = "1" DataType = "real_T" </outport>
<outport> Id = "19"  Name = "to HIL subsystem/omega_VSP2_HIL" Width = "1" DataType = "real_T" </outport>
</portlist>
