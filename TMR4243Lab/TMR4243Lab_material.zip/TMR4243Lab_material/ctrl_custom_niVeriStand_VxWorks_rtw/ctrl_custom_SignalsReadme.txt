<signallist>
<signal> Id = "0" Name = "ctrl_custom/SIXAIS_INN" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "1" Name = "ctrl_custom/Ki" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "2" Name = "ctrl_custom/Kp" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "3" Name = "ctrl_custom/EtaSetX" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "4" Name = "ctrl_custom/EtaSetY" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "5" Name = "ctrl_custom/EtaSetPsi" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "6" Name = "ctrl_custom/MomentDes" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "7" Name = "ctrl_custom/Pose/x_m" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "8" Name = "ctrl_custom/FXDes" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "9" Name = "ctrl_custom/Pose/y_m" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "10" Name = "ctrl_custom/FyDes" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "11" Name = "ctrl_custom/Pose/psi_m" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "12" Name = "ctrl_custom/ThrustAlocMethod" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "13" Name = "ctrl_custom/OBserver/SimpleObserver/Integrator" SignalName = "etahat(1, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "14" Name = "ctrl_custom/OBserver/SimpleObserver/Integrator" SignalName = "etahat(1, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "15" Name = "ctrl_custom/OBserver/SimpleObserver/Integrator" SignalName = "etahat(1, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "16" Name = "ctrl_custom/OBserver/Useobserver4Eta" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "17" Name = "ctrl_custom/DirectControl_or_Dp" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "18" Name = "ctrl_custom/Find tau_body/Detect Change/Delay Input1" SignalName = "U(k-1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "19" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Integrator2/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "20" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Integrator2/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "21" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Integrator2/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "22" Name = "ctrl_custom/Find tau_body/Simple DP controller/Sum/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "23" Name = "ctrl_custom/Find tau_body/Simple DP controller/Sum/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "24" Name = "ctrl_custom/Find tau_body/Simple DP controller/Sum/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "25" Name = "ctrl_custom/Thrust Allocation/Switch1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "26" Name = "ctrl_custom/Thrust Allocation/Switch/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "27" Name = "ctrl_custom/Thrust Allocation/Switch/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "28" Name = "ctrl_custom/Thrust Allocation/Switch/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "29" Name = "ctrl_custom/Thrust Allocation/Switch/(1, 4)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "30" Name = "ctrl_custom/Thrust Allocation/Switch/(1, 5)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "31" Name = "ctrl_custom/Thrust Allocation/Switch/(1, 6)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "32" Name = "ctrl_custom/Thrust Allocation/Switch/(1, 7)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "33" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/IC/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "34" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/IC/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "35" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/IC/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "36" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Integrator/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "37" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Integrator/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "38" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Integrator/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "39" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Saturation4/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "40" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Saturation4/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "41" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Saturation4/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "42" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Sum3/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "43" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Sum3/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "44" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/Sum3/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "45" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/w_n/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "46" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/w_n/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "47" Name = "ctrl_custom/Find tau_body/Simple DP controller/(Ref mod from  MARREG-1, not really part of task)/Reference Model/w_n/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "48" Name = "ctrl_custom/OBserver/Dead Reckoning ON//OFF  /Add" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "49" Name = "ctrl_custom/OBserver/SimpleObserver/Add" SignalName = "d_etahat(1, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "50" Name = "ctrl_custom/OBserver/SimpleObserver/Add" SignalName = "d_etahat(1, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "51" Name = "ctrl_custom/OBserver/SimpleObserver/Add" SignalName = "d_etahat(1, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "52" Name = "ctrl_custom/OBserver/SimpleObserver/Multiply2/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "53" Name = "ctrl_custom/OBserver/SimpleObserver/Multiply2/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "54" Name = "ctrl_custom/OBserver/SimpleObserver/Multiply2/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "55" Name = "ctrl_custom/OBserver/SimpleObserver/invM/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "56" Name = "ctrl_custom/OBserver/SimpleObserver/invM/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "57" Name = "ctrl_custom/OBserver/SimpleObserver/invM/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "58" Name = "ctrl_custom/IMU/Acc_z" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "59" Name = "ctrl_custom/IMU/Acc_x" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "60" Name = "ctrl_custom/IMU/Acc_y" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "61" Name = "ctrl_custom/IMU/Gyro_x" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "62" Name = "ctrl_custom/IMU/Gyro_y" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "63" Name = "ctrl_custom/IMU/Gyro_z" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "64" Name = "ctrl_custom/Find tau_body/Simple DP controller/NED->Body" SignalName = "(1, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "65" Name = "ctrl_custom/Find tau_body/Simple DP controller/NED->Body" SignalName = "(1, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "66" Name = "ctrl_custom/Find tau_body/Simple DP controller/NED->Body" SignalName = "(1, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "67" Name = "ctrl_custom/Find tau_body/Detect Change/FixPt Relational Operator" SignalName = "" PortNum = "0" Width = "1" DataType = "boolean_T" </signal>
<signal> Id = "68" Name = "ctrl_custom/OBserver/SimpleObserver/Ned-Body1" SignalName = "(1, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "69" Name = "ctrl_custom/OBserver/SimpleObserver/Ned-Body1" SignalName = "(1, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "70" Name = "ctrl_custom/OBserver/SimpleObserver/Ned-Body1" SignalName = "(1, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "71" Name = "ctrl_custom/OBserver/SimpleObserver/Ned-Body" SignalName = "(1, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "72" Name = "ctrl_custom/OBserver/SimpleObserver/Ned-Body" SignalName = "(1, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "73" Name = "ctrl_custom/OBserver/SimpleObserver/Ned-Body" SignalName = "(1, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
</signallist>
