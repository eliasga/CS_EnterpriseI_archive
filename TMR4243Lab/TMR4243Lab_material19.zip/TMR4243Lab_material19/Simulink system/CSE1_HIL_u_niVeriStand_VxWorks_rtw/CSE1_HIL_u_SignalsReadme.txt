<signallist>
<signal> Id = "0" Name = "cse1_hil_u/integrator_reset" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "1" Name = "cse1_hil_u/eta_0/Memory3" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "2" Name = "cse1_hil_u/eta_0/Memory4" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "3" Name = "cse1_hil_u/eta_0/Memory5" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "4" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/Position/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "5" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/Position/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "6" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/Position/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "7" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/Velocity/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "8" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/Velocity/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "9" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/Velocity/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "10" Name = "cse1_hil_u/u/u_BT" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "11" Name = "cse1_hil_u/u/u_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "12" Name = "cse1_hil_u/u/u_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "13" Name = "cse1_hil_u/u/alpha_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "14" Name = "cse1_hil_u/u/alpha_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "15" Name = "cse1_hil_u/u/omega_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "16" Name = "cse1_hil_u/u/omega_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "17" Name = "cse1_hil_u/Simulator_CSE1/Command2force/Sum" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "18" Name = "cse1_hil_u/Simulator_CSE1/Command2force/Add1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "19" Name = "cse1_hil_u/Simulator_CSE1/Command2force/Gain1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "20" Name = "cse1_hil_u/Simulator_CSE1/Command2force/Add" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "21" Name = "cse1_hil_u/eta_0/psi_0" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "22" Name = "cse1_hil_u/eta_0/x_0" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "23" Name = "cse1_hil_u/eta_0/y_0" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "24" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/kinetics" SignalName = "(1, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "25" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/kinetics" SignalName = "(1, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "26" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/kinetics" SignalName = "(1, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "27" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/kinematics" SignalName = "(1, 1)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "28" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/kinematics" SignalName = "(1, 2)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "29" Name = "cse1_hil_u/Simulator_CSE1/EquationsOfMotion_FossenModel/kinematics" SignalName = "(1, 3)" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "30" Name = "cse1_hil_u/Simulator_CSE1/Command2force/VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "31" Name = "cse1_hil_u/Simulator_CSE1/Command2force/VSP1" SignalName = "" PortNum = "1" Width = "1" DataType = "real_T" </signal>
<signal> Id = "32" Name = "cse1_hil_u/Simulator_CSE1/Command2force/VSP" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "33" Name = "cse1_hil_u/Simulator_CSE1/Command2force/VSP" SignalName = "" PortNum = "1" Width = "1" DataType = "real_T" </signal>
</signallist>
