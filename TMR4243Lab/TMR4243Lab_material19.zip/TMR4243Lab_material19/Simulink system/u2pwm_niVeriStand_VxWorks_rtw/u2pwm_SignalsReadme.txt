<signallist>
<signal> Id = "0" Name = "u2pwm/Switch_subsystem/Triangle" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "1" Name = "u2pwm/Switch_subsystem/Circle" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "2" Name = "u2pwm/Switch_subsystem/Cross" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "3" Name = "u2pwm/Switch_subsystem/Square" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "4" Name = "u2pwm/Switch_subsystem/Memory" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "5" Name = "u2pwm/ctrl_custom/u_BT" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "6" Name = "u2pwm/ctrl_custom/u_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "7" Name = "u2pwm/ctrl_custom/omega_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "8" Name = "u2pwm/ctrl_custom/omega_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "9" Name = "u2pwm/ctrl_custom/u_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "10" Name = "u2pwm/ctrl_custom/alpha_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "11" Name = "u2pwm/ctrl_custom/alpha_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "12" Name = "u2pwm/ctrl_DP/u_BT" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "13" Name = "u2pwm/ctrl_DP/u_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "14" Name = "u2pwm/ctrl_DP/omega_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "15" Name = "u2pwm/ctrl_DP/omega_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "16" Name = "u2pwm/ctrl_DP/u_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "17" Name = "u2pwm/ctrl_DP/alpha_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "18" Name = "u2pwm/ctrl_DP/alpha_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "19" Name = "u2pwm/ctrl_sixaxis2thruster/u_BT" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "20" Name = "u2pwm/ctrl_sixaxis2thruster/u_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "21" Name = "u2pwm/ctrl_sixaxis2thruster/omega_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "22" Name = "u2pwm/ctrl_sixaxis2thruster/omega_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "23" Name = "u2pwm/ctrl_sixaxis2thruster/u_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "24" Name = "u2pwm/ctrl_sixaxis2thruster/alpha_VSP1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "25" Name = "u2pwm/ctrl_sixaxis2thruster/alpha_VSP2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "26" Name = "u2pwm/Multiport Switch/(1, 1)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "27" Name = "u2pwm/Multiport Switch/(1, 2)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "28" Name = "u2pwm/Multiport Switch/(1, 3)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "29" Name = "u2pwm/Multiport Switch/(1, 4)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "30" Name = "u2pwm/Multiport Switch/(1, 5)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "31" Name = "u2pwm/Multiport Switch/(1, 6)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "32" Name = "u2pwm/Multiport Switch/(1, 7)" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "33" Name = "u2pwm/enable_mech_el" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "34" Name = "u2pwm/u2pwm/Sum1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "35" Name = "u2pwm/u2pwm/Sum" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "36" Name = "u2pwm/u2pwm/BT_system/Merge" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "37" Name = "u2pwm/u2pwm/BT_system/Sum2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "38" Name = "u2pwm/u2pwm/2-D Lookup Table3" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "39" Name = "u2pwm/u2pwm/2-D Lookup Table2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "40" Name = "u2pwm/u2pwm/2-D Lookup Table" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "41" Name = "u2pwm/u2pwm/2-D Lookup Table1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "42" Name = "u2pwm/emulate mechanical and electrical system/Sum" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "43" Name = "u2pwm/emulate mechanical and electrical system/Sum1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "44" Name = "u2pwm/emulate mechanical and electrical system/Sum2" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "45" Name = "u2pwm/emulate mechanical and electrical system/Sum3" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "46" Name = "u2pwm/emulate mechanical and electrical system/Sum4" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "47" Name = "u2pwm/emulate mechanical and electrical system/Sum5" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "48" Name = "u2pwm/emulate mechanical and electrical system/Sum6" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "49" Name = "u2pwm/u2pwm/BT_system/Gain6" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "50" Name = "u2pwm/Switch_subsystem/Switch_function" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "51" Name = "u2pwm/indicator/C" SignalName = "" PortNum = "0" Width = "1" DataType = "boolean_T" </signal>
<signal> Id = "52" Name = "u2pwm/indicator/C" SignalName = "" PortNum = "1" Width = "1" DataType = "boolean_T" </signal>
<signal> Id = "53" Name = "u2pwm/indicator/C" SignalName = "" PortNum = "2" Width = "1" DataType = "boolean_T" </signal>
<signal> Id = "54" Name = "u2pwm/indicator/C" SignalName = "" PortNum = "3" Width = "1" DataType = "boolean_T" </signal>
<signal> Id = "55" Name = "u2pwm/control limit checking" SignalName = "" PortNum = "0" Width = "1" DataType = "boolean_T" </signal>
</signallist>
