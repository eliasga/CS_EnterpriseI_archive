<parameterlist>
<parameter> Id = "0" Inline = "0" Name = "ctrl_sixaxis2thruster/Subsystem/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "1" Inline = "0" Name = "ctrl_sixaxis2thruster/Subsystem/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "2" Inline = "0" Name = "ctrl_sixaxis2thruster/Subsystem/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "3" Inline = "0" Name = "ctrl_sixaxis2thruster/Subsystem1/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "4" Inline = "0" Name = "ctrl_sixaxis2thruster/Subsystem1/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "5" Inline = "0" Name = "ctrl_sixaxis2thruster/Subsystem1/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "6" Inline = "0" Name = "ctrl_sixaxis2thruster/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "7" Inline = "0" Name = "ctrl_sixaxis2thruster/VSP omega/Memory/X0" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "8" Inline = "0" Name = "ctrl_sixaxis2thruster/VSP omega/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "9" Inline = "0" Name = "ctrl_sixaxis2thruster/VSP omega/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
</parameterlist>
