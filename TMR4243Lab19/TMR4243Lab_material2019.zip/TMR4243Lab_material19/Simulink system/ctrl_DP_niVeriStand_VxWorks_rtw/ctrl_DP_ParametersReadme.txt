<parameterlist>
<parameter> Id = "0" Inline = "0" Name = "ctrl_dp/POSE/mm2m/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "1" Inline = "0" Name = "ctrl_dp/POSE/mm2m/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "2" Inline = "0" Name = "ctrl_dp/POSE/Gain5/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "3" Inline = "0" Name = "ctrl_dp/POSE/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "4" Inline = "0" Name = "ctrl_dp/POSE/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "5" Inline = "0" Name = "ctrl_dp/POSE/Gain6/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "6" Inline = "0" Name = "ctrl_dp/POSE/Constant1/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "7" Inline = "0" Name = "ctrl_dp/Control/DP Controller/[-inf inf] to [-pi pi]1/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "8" Inline = "0" Name = "ctrl_dp/Control/DP Controller/[-inf inf] to [-pi pi]1/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "9" Inline = "0" Name = "ctrl_dp/Control/DP Controller/[-inf inf] to [-pi pi]1/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "10" Inline = "0" Name = "ctrl_dp/Control/DP Controller/[-inf inf] to [-pi pi]1/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "11" Inline = "0" Name = "ctrl_dp/Input/Observer Gains/Constant6/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "12" Inline = "0" Name = "ctrl_dp/Input/Observer Gains/Constant7/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "13" Inline = "0" Name = "ctrl_dp/Input/Observer Gains/Constant8/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "14" Inline = "0" Name = "ctrl_dp/Guidance/Reference model/[-inf inf] to [-pi pi]1/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "15" Inline = "0" Name = "ctrl_dp/Guidance/Reference model/[-inf inf] to [-pi pi]1/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "16" Inline = "0" Name = "ctrl_dp/Guidance/Reference model/[-inf inf] to [-pi pi]1/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "17" Inline = "0" Name = "ctrl_dp/Guidance/Reference model/[-inf inf] to [-pi pi]1/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "18" Inline = "0" Name = "ctrl_dp/Control/DP Controller/[-inf inf] to [-pi pi]/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "19" Inline = "0" Name = "ctrl_dp/Control/DP Controller/[-inf inf] to [-pi pi]/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "20" Inline = "0" Name = "ctrl_dp/Control/DP Controller/[-inf inf] to [-pi pi]/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "21" Inline = "0" Name = "ctrl_dp/Control/DP Controller/[-inf inf] to [-pi pi]/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "22" Inline = "0" Name = "ctrl_dp/Control/DP Controller/Integrator/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "23" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/Integrator1/InitialCondition" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "24" Inline = "0" Name = "ctrl_dp/Guidance/Reference model/Integrator3/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "25" Inline = "0" Name = "ctrl_dp/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "26" Inline = "0" Name = "ctrl_dp/IMU/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "27" Inline = "0" Name = "ctrl_dp/IMU/Gain1/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "28" Inline = "0" Name = "ctrl_dp/IMU/Gain2/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "29" Inline = "0" Name = "ctrl_dp/Memory/X0" Width = "81" DataType = "real_T" </parameter>
<parameter> Id = "30" Inline = "0" Name = "ctrl_dp/Memory1/X0" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "31" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/[-inf inf] to [-pi pi]/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "32" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/[-inf inf] to [-pi pi]/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "33" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/[-inf inf] to [-pi pi]/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "34" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/[-inf inf] to [-pi pi]/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "35" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/[-inf inf] to [-pi pi]1/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "36" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/[-inf inf] to [-pi pi]1/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "37" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/[-inf inf] to [-pi pi]1/Gain/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "38" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/[-inf inf] to [-pi pi]1/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "39" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/Integrator2/InitialCondition" Width = "3" DataType = "real_T" </parameter>
<parameter> Id = "40" Inline = "0" Name = "ctrl_dp/Nonlinear Passisve Observer/M^-1/Gain" Width = "9" DataType = "real_T" </parameter>
<parameter> Id = "41" Inline = "0" Name = "ctrl_dp/Guidance/Reference model/Integrator2/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "42" Inline = "0" Name = "ctrl_dp/Input/Observer Gains/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "43" Inline = "0" Name = "ctrl_dp/Input/Observer Gains/Constant1/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "44" Inline = "0" Name = "ctrl_dp/Input/Observer Gains/Constant2/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "45" Inline = "0" Name = "ctrl_dp/Input/Observer Gains/Constant3/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "46" Inline = "0" Name = "ctrl_dp/Input/Observer Gains/Constant4/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "47" Inline = "0" Name = "ctrl_dp/Input/Observer Gains/Constant5/Value" Width = "1" DataType = "real_T" </parameter>
</parameterlist>
