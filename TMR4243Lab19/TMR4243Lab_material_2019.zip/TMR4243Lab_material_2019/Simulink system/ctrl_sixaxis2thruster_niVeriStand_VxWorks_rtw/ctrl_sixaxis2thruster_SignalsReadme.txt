<signallist>
<signal> Id = "0" Name = "ctrl_sixaxis2thruster/PosXLeft" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "1" Name = "ctrl_sixaxis2thruster/PosYLeft" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "2" Name = "ctrl_sixaxis2thruster/Subsystem/Saturation" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "3" Name = "ctrl_sixaxis2thruster/PosYRight" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "4" Name = "ctrl_sixaxis2thruster/PosXRight" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "5" Name = "ctrl_sixaxis2thruster/Subsystem1/Trigonometric Function1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "6" Name = "ctrl_sixaxis2thruster/Subsystem/Trigonometric Function1" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "7" Name = "ctrl_sixaxis2thruster/Subsystem1/Saturation" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "8" Name = "ctrl_sixaxis2thruster/Start" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "9" Name = "ctrl_sixaxis2thruster/ArrowUp" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "10" Name = "ctrl_sixaxis2thruster/L2_continuous" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "11" Name = "ctrl_sixaxis2thruster/R2_continuous" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "12" Name = "ctrl_sixaxis2thruster/Gain" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "13" Name = "ctrl_sixaxis2thruster/ArrowDown" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
<signal> Id = "14" Name = "ctrl_sixaxis2thruster/VSP omega/Saturation" SignalName = "" PortNum = "0" Width = "1" DataType = "real_T" </signal>
</signallist>
